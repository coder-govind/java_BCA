/* Create a Java program to access the java.util.Date class through qualified way and print the current date of the system.*/

public class packages2_7024 {
    public static void main(String[] args) {
        java.util.Date currentDate = new java.util.Date();
        System.out.println("Current Date: " + currentDate);
    }
}