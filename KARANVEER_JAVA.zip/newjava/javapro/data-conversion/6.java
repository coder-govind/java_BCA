
//How to convert float to String
public class FloatToString 
{
	public static void main(String[] args) 
	{
		float f = 10.4f;
		System.out.println(f + 2);
		String stringValue = "" + f;
		System.out.println(stringValue + 2);
	}

}
