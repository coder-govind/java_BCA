// Add event listener to menu button
document.getElementById('menu-btn').addEventListener('click', () => {
    document.getElementById('navbar').classList.toggle('active');
});

// Add event listener to menu close button
document.getElementById('menu-close').addEventListener('click', () => {
    document.getElementById('navbar').classList.remove('active');
});

// Add event listener to course cards
document.querySelectorAll('.course-card').forEach((card) => {
    card.addEventListener('click', () => {
        card.classList.toggle('active');
    });
});