class ArrayLength{
    public static void main(String[] args) {
        // Declare and initialize an array
        int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        // Get the length of the array
        int arrayLength = numbers.length;
        // Print the number of elements in the array
        System.out.println("The number of elements in the array is: " + arrayLength);
    }
}
