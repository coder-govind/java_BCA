/*Create a class showing an example of default constructor. */
class Construct1 {
    Construct1() {
        System.out.println("This is a Default Constructor");
    }

    public static void main(String args[]) {
        Construct1 C = new Construct1();
    }

}