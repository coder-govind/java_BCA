
import java.util.Scanner;
//Enter the long integer from user using Scanner class
class LongUsingScanner 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a long integer : ");
		long l = sc.nextLong();
		System.out.println("long integer is : "+l);
		
	}

}
