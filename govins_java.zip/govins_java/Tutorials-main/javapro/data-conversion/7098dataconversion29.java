class GFG {
 
    public static void main(String args[])
    {
        
        String onum = "157";
 
        
        int num = Integer.parseInt(onum, 8);
 
        System.out.println(
            "Decimal equivalent of Octal value 157 is: "
            + num);
    }
}