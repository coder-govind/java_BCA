
// Using Concept of Type-casting 
import java.util.*; 

class A { 

	public static void main(String[] args) 
	{ 

		
		int i = 97; 

		// Type casting character to integer 
		char ch = (char)i; 

		System.out.println(ch); 
	} 
}
