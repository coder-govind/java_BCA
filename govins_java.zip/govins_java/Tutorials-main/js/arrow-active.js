$('.icon-up').click(function () {
    $(this).toggleClass('rotate')
  })